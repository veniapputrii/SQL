-----------------REMOVING ALL OF THE TABLES--------------------------------

DROP TABLE IF EXISTS product;

DROP TABLE IF EXISTS pattern;

DROP TABLE IF EXISTS product_pattern;

DROP TABLE IF EXISTS employee;

DROP TABLE IF EXISTS employee_worklog;