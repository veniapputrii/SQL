-- 1. LIKE--
--use like to select how many employee are from Gayam city?
SELECT
	*
FROM
	employee
WHERE
	address LIKE '%Gayam%';
-- 2. JOIN--
-- report of completed product prices in the first day of october
SELECT
	ew.product_id,
	ew.employee_id,
	p.price,
	ew.actual_meters_used,
	ew.completed_quantity,
	ew.work_date
FROM
	product p
INNER JOIN employee_worklog ew ON
	p.product_id = ew.product_id
WHERE
	ew.work_date = '01/10/26';
--3. >
-- which product that use more than 500 m material
SELECT
	product_id,
	employee_id,
	actual_meters_used,
	completed_quantity,
	work_date
FROM
	employee_worklog
WHERE
	actual_meters_used > 500;
--4. Group BY
-- expected consumption for each product
SELECT
	pp.product_id,
	p2.product_name,
	p2.size, 
	sum(p.standard_meters_required * pp.quantity_required) AS total_meters_required
FROM
	pattern p
INNER JOIN product_pattern pp ON
	p.pattern_id = pp.pattern_id
INNER JOIN product p2 ON
	p2.product_id = pp.product_id
GROUP BY
	pp.product_id ;
--the AVG actual meter used each product by employees
SELECT
	product_id,
	round(avg(actual_meters_used), 2) AS avg_consumption,
	group_concat(DISTINCT employee_id) AS employee_ids
FROM
	employee_worklog
GROUP BY
	product_id;
--5. IN
--how many M size in the pattern table
SELECT
	*
FROM
	pattern
WHERE
	SIZE IN ('M');

--6. UPDATE
-- Add a new quantity 
BEGIN;

UPDATE
	product
SET
	ready_quantity = ready_quantity + 1,
	price = price * 1.50
WHERE
	SIZE = 'M';

-- to see the result before undo
-- SELECT * FROM product; ---
ROLLBACK; 

-- change the lowercase to uppercase for the first letter
BEGIN;
UPDATE
	product
SET
	product_name = 'Gabriela'
WHERE
	product_name = 'gabriela';

-- to see the result before undo
-- SELECT * FROM product; ---
ROLLBACK;

BEGIN;
UPDATE
	product
SET
	product_name = 'Nadin'
WHERE
	product_name = 'nadin';

-- to see the result before undo
-- SELECT * FROM product; ---
ROLLBACK;

-- and show the product only that has size M
SELECT
	*
FROM
	product
WHERE
	SIZE = 'M';

SELECT
	*
FROM
	product;