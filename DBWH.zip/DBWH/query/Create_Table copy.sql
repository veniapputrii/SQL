--CREATE TABLES--
--create the product table
BEGIN; --to prevent from error, nothing is created--
CREATE TABLE IF NOT EXISTS product(
product_id integer PRIMARY KEY,
product_name varchar (50),
price decimal(7, 2),
SIZE varchar(50),
ready_quantity bigint
);
--create the pattern table
CREATE TABLE IF NOT EXISTS pattern(
pattern_id varchar(50) PRIMARY KEY,
pattern_name varchar(50),
standard_meters_required decimal(6, 2),
width_cm decimal(6, 2),
heigth_cm decimal(6, 2),
SIZE varchar(5)
)
--create the product_pattern table
CREATE TABLE IF NOT EXISTS product_pattern(
product_id bigint,
pattern_id varchar(50),
quantity_required integer,
PRIMARY KEY(product_id, pattern_id),
FOREIGN KEY(product_id) REFERENCES product (product_id),
FOREIGN KEY(pattern_id) REFERENCES pattern (pattern_id)
);
--create the employee table
CREATE TABLE IF NOT EXISTS employee(
    employee_id integer PRIMARY KEY,
    name varchar(50),
    address varchar,
    experience_years integer
);
--create the employee_working table
CREATE TABLE employee_worklog(
worklog_id integer PRIMARY KEY,
employee_id integer,
product_id bigint, 
completed_quantity integer,
actual_meters_used decimal(10, 2),
work_date date ,
FOREIGN KEY(employee_id) REFERENCES employee(employee_id),
FOREIGN KEY(product_id) REFERENCES product(product_id)
);

COMMIT; --confirms everything can be saved
ROLLBACK; --cancels the last query after begin part